using System;
using System.Text.RegularExpressions;
using System.Web.UI;

namespace UserRegistrationApp
{
    public partial class RegistrationForm : Page
    {
        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            string name = NameTextBox.Text.Trim();
            string password = PasswordTextBox.Text;
            string confirmPassword = ConfirmPasswordTextBox.Text;
            int age;
            string email = EmailTextBox.Text.Trim();
            string userId = UserIdTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirmPassword) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(userId))
            {
                ResultLabel.Text = "Please fill in all the fields.";
                return;
            }

            if (password != confirmPassword)
            {
                ResultLabel.Text = "Passwords do not match.";
                return;
            }

            if (!int.TryParse(AgeTextBox.Text, out age) || age < 21 || age > 30)
            {
                ResultLabel.Text = "Age must be a number between 21 and 30.";
                return;
            }

            if (!IsValidEmail(email))
            {
                ResultLabel.Text = "Invalid email address.";
                return;
            }

            if (!IsValidUserId(userId))
            {
                ResultLabel.Text = "User ID must have at least one capital letter, one digit, and be between 7 and 20 characters long.";
                return;
            }

            // If all validation passes, you can proceed with saving the user data
            // For simplicity, let's just display a success message here
            ResultLabel.Text = "Registration successful!";
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidUserId(string userId)
        {
            return Regex.IsMatch(userId, @"^(?=.*[A-Z])(?=.*\d).{7,20}$");
        }
    }
}
