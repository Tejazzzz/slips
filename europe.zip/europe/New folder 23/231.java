import java.awt.BorderLayout;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class CollegeDetails {
    public static void main(String[] args) {
        // College details
        Vector<String> columnNames = new Vector<>(Arrays.asList("CID", "CName", "Address"));
        Vector<Vector<String>> data = new Vector<>();

        // Sample data
        data.add(new Vector<>(Arrays.asList("1", "College1", "Address1")));
        data.add(new Vector<>(Arrays.asList("2", "College2", "Address2")));
        data.add(new Vector<>(Arrays.asList("3", "College3", "Address3")));

        // Create JTable
        JTable table = new JTable(data, columnNames);

        // Create JFrame
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Add JTable to JFrame
        frame.add(new JScrollPane(table), BorderLayout.CENTER);

        // Display JFrame
        frame.setVisible(true);
    }
}