import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EmpTable {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/mydatabase";
    static final String USER = "username";
    static final String PASS = "password";

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Create table
            System.out.println("Creating table Emp...");
            String createTableSql = "CREATE TABLE Emp (ENo INT, EName VARCHAR(255), Sal FLOAT)";
            pstmt = conn.prepareStatement(createTableSql);
            pstmt.executeUpdate();
            System.out.println("Table created successfully");

            // Insert a record
            System.out.println("Inserting record into table Emp...");
            String insertSql = "INSERT INTO Emp (ENo, EName, Sal) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(insertSql);
            pstmt.setInt(1, 101);
            pstmt.setString(2, "John");
            pstmt.setFloat(3, 5000.00f);
            pstmt.executeUpdate();
            System.out.println("Record inserted successfully");

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Finally block used to close resources
            try {
                if (pstmt != null) pstmt.close();
            } catch (SQLException se2) {
            } // nothing we can do
            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            } // End finally try
        } // End try
        System.out.println("Goodbye!");
    }
}
