using System;

class Program
{
    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Addition");
            Console.WriteLine("2. Subtraction");
            Console.WriteLine("3. Multiplication");
            Console.WriteLine("4. Division");
            Console.WriteLine("5. Exit");
            Console.Write("Enter your choice: ");

            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Addition();
                    break;
                case 2:
                    Subtraction();
                    break;
                case 3:
                    Multiplication();
                    break;
                case 4:
                    Division();
                    break;
                case 5:
                    Console.WriteLine("Exiting program...");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                    break;
            }

            Console.WriteLine();
        }
    }

    static void Addition()
    {
        Console.Write("Enter first number: ");
        double num1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Enter second number: ");
        double num2 = Convert.ToDouble(Console.ReadLine());
        double result = num1 + num2;
        Console.WriteLine($"Result: {num1} + {num2} = {result}");
    }

    static void Subtraction()
    {
        Console.Write("Enter first number: ");
        double num1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Enter second number: ");
        double num2 = Convert.ToDouble(Console.ReadLine());
        double result = num1 - num2;
        Console.WriteLine($"Result: {num1} - {num2} = {result}");
    }

    static void Multiplication()
    {
        Console.Write("Enter first number: ");
        double num1 = Convert.ToDouble(Console.ReadLine());
        Console.Write("Enter second number: ");
        double num2 = Convert.ToDouble(Console.ReadLine());
        double result = num1 * num2;
        Console.WriteLine($"Result: {num1} * {num2} = {result}");
    }

    static void Division()
    {
        Console.Write("Enter dividend: ");
        double dividend = Convert.ToDouble(Console.ReadLine());
        Console.Write("Enter divisor: ");
        double divisor = Convert.ToDouble(Console.ReadLine());
        
        if (divisor == 0)
        {
            Console.WriteLine("Error: Division by zero is not allowed.");
            return;
        }
        
        double result = dividend / divisor;
        Console.WriteLine($"Result: {dividend} / {divisor} = {result}");
    }
}
