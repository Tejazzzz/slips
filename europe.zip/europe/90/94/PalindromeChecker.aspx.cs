using System;

public partial class PalindromeChecker : System.Web.UI.Page
{
    protected void check_Click(object sender, EventArgs e)
    {
        string input = getnum.Text;
        string reversed = ReverseString(input);

        if (input.Equals(reversed))
        {
            lbldisplay.Text = $"{input} is a palindrome.";
        }
        else
        {
            lbldisplay.Text = $"{input} is not a palindrome.";
        }
    }

    private string ReverseString(string input)
    {
        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }
}
