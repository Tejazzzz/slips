using System;
using System.Web.UI;

namespace UserControlsExample
{
    public partial class LoginControl : UserControl
    {
        protected void LoginButton_Click(object sender, EventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordTextBox.Text.Trim();

            // Check if the username and password are valid
            if (username == "DYP" && password == "yourpassword")
            {
                ResultLabel.Text = "Login successful!";
                // You can perform additional actions here, such as redirecting to another page
            }
            else
            {
                ResultLabel.Text = "Invalid username or password. Please try again.";
            }
        }
    }
}
