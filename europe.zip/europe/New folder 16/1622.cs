using System;

class Supplier
{
    public int sid;
    public string name;
    public string address;
    public int pincode;

    public Supplier(int sid, string name, string address, int pincode)
    {
        this.sid = sid;
        this.name = name;
        this.address = address;
        this.pincode = pincode;
    }

    public void DisplayDetails()
    {
        Console.WriteLine($"Supplier ID: {sid}");
        Console.WriteLine($"Name: {name}");
        Console.WriteLine($"Address: {address}");
        Console.WriteLine($"Pincode: {pincode}");
        Console.WriteLine();
    }
}

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the number of suppliers: ");
        int n = Convert.ToInt32(Console.ReadLine());

        Supplier[] suppliers = new Supplier[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nEnter details for supplier {i + 1}:");
            Console.Write("Supplier ID: ");
            int sid = Convert.ToInt32(Console.ReadLine());

            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            Console.Write("Pincode: ");
            int pincode = Convert.ToInt32(Console.ReadLine());

            suppliers[i] = new Supplier(sid, name, address, pincode);
        }

        Console.WriteLine("\nSupplier details:");
        foreach (Supplier supplier in suppliers)
        {
            supplier.DisplayDetails();
        }
    }
}
