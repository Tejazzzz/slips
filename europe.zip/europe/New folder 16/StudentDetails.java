import java.sql.*;

public class StudentDetails {
    public static void main(String[] args) {
        try {
            // Connect to database
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "project");

            String insertSql = "INSERT INTO students (rno, sname, per) VALUES (?, ?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setInt(1, 1);
            insertStmt.setString(2, "AAA");
            insertStmt.setFloat(3, 79.0f);
            insertStmt.executeUpdate();

            insertStmt.setInt(1, 2);
            insertStmt.setString(2, "BBB");
            insertStmt.setFloat(3, 90.0f);
            insertStmt.executeUpdate();

            insertStmt.setInt(1, 3);
            insertStmt.setString(2, "CCC");
            insertStmt.setFloat(3, 80.0f);
            insertStmt.executeUpdate();

            insertStmt.setInt(1, 4);
            insertStmt.setString(2, "DDD");
            insertStmt.setFloat(3, 95.0f);
            insertStmt.executeUpdate();

            insertStmt.setInt(1, 5);
            insertStmt.setString(2, "EEE");
            insertStmt.setFloat(3, 75.0f);
            insertStmt.executeUpdate();

            String selectSql = "SELECT * FROM students WHERE per = (SELECT MAX(per) FROM students)";
            PreparedStatement selectStmt = conn.prepareStatement(selectSql);
            ResultSet rs = selectStmt.executeQuery();

            while (rs.next()) {
                int rno = rs.getInt("rno");
                String sname = rs.getString("sname");
                float per = rs.getFloat("per");
                System.out.println("Roll No: " + rno + ", Name: " + sname + ", Percentage: " + per);
            }

            rs.close();
            selectStmt.close();
            insertStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
